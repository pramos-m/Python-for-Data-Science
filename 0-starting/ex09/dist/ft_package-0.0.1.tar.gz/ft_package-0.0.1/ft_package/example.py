def count_in_list(myList, myString):
    return myList.count(myString)
